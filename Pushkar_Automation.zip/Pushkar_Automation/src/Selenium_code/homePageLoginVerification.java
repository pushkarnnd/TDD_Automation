package Selenium_code;
import objectClass.*;

import java.io.FileInputStream;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;


public class homePageLoginVerification extends baseTestClass{
	
	@BeforeMethod
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");	
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();	
		driver.get("https://app.recruitcrm.io/");		
	}
	
	
	@Parameters({ "emailID", "Password" })
	@Test()
	public void passwordFailureCheck(String email, String password) throws Exception
    {
		
		obj_homePageLoginVerification.emailString(driver).sendKeys(email);
		obj_homePageLoginVerification.passwordString(driver).sendKeys(password);
		
		obj_homePageLoginVerification.userLogInSuccess(driver).click();
		
		Thread.sleep(5000);
		Assert.assertEquals(driver.findElement(By.xpath("//h1[text()='Login to Recruit CRM']")).getText(), "Login to Recruit CRM");
		
	}
	
	
	@Test
	public void userLogIn() throws Exception
	{
		
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"/test.properties");
		Properties property = new Properties();
		property.load(fs);
		
		obj_homePageLoginVerification.emailString(driver).sendKeys(property.getProperty("EmailID2"));
		obj_homePageLoginVerification.passwordString(driver).sendKeys(property.getProperty("Password2"));
		
		obj_homePageLoginVerification.userLogInSuccess(driver).click(); 
		
		//Assert.assertTrue(obj_homePageLoginVerification.logoCheck(driver).isDisplayed());
		
		System.out.print("Login Successful");
				
	}
	
    @Test
    public void userSignOut() throws Exception {
        obj_verifyWebElement.loginMethod(driver);
		
		Assert.assertTrue(driver.findElement(By.className("logo")).isDisplayed());
		Thread.sleep(5000);
		
		
		driver.findElement(By.xpath("//img[@class='user-dropdown-link']")).click();	
			
		Thread.sleep(2000);
		driver.findElement(By.id("sTest-signOutInAppBtn")).click();
		Assert.assertEquals(driver.findElement(By.xpath("//h1[text()='Login to Recruit CRM']")).getText(), "Login to Recruit CRM");
    	
    }
	
	@AfterMethod
	public void closeBrowser(){
		driver.quit();
	}
	
	
}