package Selenium_code;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import objectClass.obj_verifyWebElement;

public class verifyWebElements extends baseTestClass{
	
		SoftAssert a;
		
	
	@BeforeMethod
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();	
		driver.get("https://app.recruitcrm.io/");	
		a = new SoftAssert();
	}
	

	

	
	@Test
	public void verifyDropDown() throws Exception {
		
		obj_verifyWebElement.loginMethod(driver);
		Assert.assertTrue(driver.findElement(By.className("logo")).isDisplayed());
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//a[@class='button'][1]")).click();
		driver.findElement(By.xpath("//a[@id='sTest-filterJobByUser']//following::a[@class='dropdown-item'and@id='sTest-filterJobByUser'][1]")).click();
		Thread.sleep(3000);
		
        Assert.assertEquals(driver.findElement(By.xpath("//a[@class='button'][1]")).getText(), "Pushkar 's Candidate Statistics");
	}
	
	
	@Test
	public void verifylinks() throws Exception, IOException {
		
		
		obj_verifyWebElement.loginMethod(driver);
		Assert.assertTrue(driver.findElement(By.className("logo")).isDisplayed());
		Thread.sleep(5000);
		
		 List<WebElement> links=   driver.findElements(By.cssSelector("li[class='menu-item'] a"));

	      SoftAssert a =new SoftAssert();

	      for(WebElement link : links)

	      {

	          String url= link.getAttribute("href");

	          HttpURLConnection   conn= (HttpURLConnection)new URL(url).openConnection();

	          conn.setRequestMethod("HEAD");

	          conn.connect();

	          int respCode = conn.getResponseCode();

	          System.out.println(respCode);

	          a.assertTrue(respCode<400, "The link with Text"+link.getText()+" is broken with code" +respCode);

	      }

	      a.assertAll();
 
	}
	
	
	@Test
	public void verifybutton() throws Exception {
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
	   obj_verifyWebElement.loginMethod(driver);
		
		Assert.assertTrue(driver.findElement(By.className("logo")).isDisplayed());
		Thread.sleep(5000);
		
		
		driver.findElement(By.xpath("//img[@class='user-dropdown-link']")).click();	
			
		Thread.sleep(2000);
		driver.findElement(By.id("sTest-profileInAppBtn")).click();
		Thread.sleep(5000);
		
	
		WebElement city = driver.findElement(By.id("sTest-userCity"));
		
		Thread.sleep(3000);
		city.sendKeys(Keys.CONTROL + "a");
		city.sendKeys(Keys.DELETE);
		
		//driver.findElement(By.id("sTest-userCity")).clear();
		driver.findElement(By.id("sTest-userCity")).sendKeys("Noida");
		
		js.executeScript("window.scrollBy(0,300)");
		
		driver.findElement(By.id("sTest-btnSaveProfile")).click();
		Thread.sleep(3000);
		
	}
	

	

	

	@AfterMethod
	public void closeBrowser(){
		driver.quit();
	}

}
