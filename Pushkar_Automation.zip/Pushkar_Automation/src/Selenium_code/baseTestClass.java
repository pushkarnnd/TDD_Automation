package Selenium_code;

import java.awt.Robot;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class baseTestClass {
	
	WebDriver driver;
    Properties property;
	FileInputStream fs;
	Robot robot;

}
