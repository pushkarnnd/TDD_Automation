package Selenium_code;
import objectClass.obj_homePageVerification;


import java.io.FileInputStream;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class homePageVerification extends baseTestClass {

	 WebDriver driver ;
	    Properties property;
		FileInputStream fs;
		
	
	
	@BeforeMethod
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");	
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();	
		driver.get("https://app.recruitcrm.io/");
	}
	
	@Test (priority = 1)
	public void verifyPageTitleTest() {
	
		System.out.println("The Page Title is "+ obj_homePageVerification.getTitle(driver));
		Assert.assertEquals(obj_homePageVerification.getTitle(driver), "Recruit CRM");
		
	}
	
	@Test (priority = 2)
	public void verifyLogoTest() {
		boolean flag = obj_homePageVerification.logoCheck(driver).isDisplayed();
		Assert.assertTrue(flag);
	}
	
	
	
	
	@AfterMethod
	public void closeBrowser(){
		driver.quit();
	}
	
}
