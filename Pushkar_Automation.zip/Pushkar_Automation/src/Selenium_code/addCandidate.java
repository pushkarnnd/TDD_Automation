package Selenium_code;
import objectClass.*;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;


public class addCandidate extends baseTestClass{
	
	
	
	@BeforeMethod
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");	
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();	
		driver.get("https://app.recruitcrm.io/");	
	
	}
	
	
	@Test(priority=1)
	public void addCandidates() throws Exception 
    {
		Robot robot = new Robot();
		
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"/test.properties");
		Properties property = new Properties();
		property.load(fs);
		
		obj_addCandidate.emailString(driver).sendKeys(property.getProperty("EmailID2"));
		obj_addCandidate.passwordString(driver).sendKeys(property.getProperty("Password2"));
		
		obj_addCandidate.userLogInSuccess(driver).click();
		Thread.sleep(2000);
	
		
		obj_addCandidate.clickOnIcon(driver).click();
		
		driver.findElement(By.id("sTest-addCandidateBtn")).click();
		
		driver.findElement(By.id("sTest-candidateFirstName")).sendKeys(property.getProperty("Firstname"));
		driver.findElement(By.id("sTest-candidateLastName")).sendKeys(property.getProperty("Lastname"));
		driver.findElement(By.id("sTest-candidateEmail")).sendKeys(property.getProperty("EmailID2"));
		
		driver.findElement(By.xpath("//section[@class='section']")).click();
		robot.setAutoDelay(3000);
		StringSelection stringSelection = new StringSelection(System.getProperty("user.dir")+"\\abc.txt");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
		
		robot.setAutoDelay(3000);
		
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		
		
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		robot.setAutoDelay(20000);
	
		
		
		driver.findElement(By.id("sTest-candidateAddBtn")).click();
		Thread.sleep(10000);
		//Assert.assertTrue(driver.findElement(By.xpath("//span[@class='file-name']")).isDisplayed());

	}
	
	@Test(priority=2)
	public void deleteCandidates() throws Exception 
    {
	
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"/test.properties");
		Properties property = new Properties();
		property.load(fs);
		
		obj_addCandidate.emailString(driver).sendKeys(property.getProperty("EmailID2"));
		obj_addCandidate.passwordString(driver).sendKeys(property.getProperty("Password2"));
		
		obj_addCandidate.userLogInSuccess(driver).click();
		Thread.sleep(2000);
	
		
		obj_addCandidate.clickOnIcon(driver).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//tbody/tr[1]/td[1]/label[1]/span[1]")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.id("sTest-deleteBulkBtn")).click();
		Thread.sleep(2000);
		driver.findElement(By.name("Records Count")).sendKeys("1");
		driver.findElement(By.id("sTest-deleteForeverBtn")).click();
        Thread.sleep(5000);
        
        Assert.assertEquals(driver.findElement(By.xpath("//p[text()='This Record Has Been Removed']")).getText(), "This Record Has Been Removed");
        
        Thread.sleep(5000);
    }

	
	@AfterMethod
	public void closeBrowser(){
		driver.quit();
	}
	
	
}