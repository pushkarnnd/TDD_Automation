package objectClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Selenium_code.*;

public class obj_homePageVerification extends baseTestClass {
	
	static WebElement element = null;
	
	public static WebElement logoCheck(WebDriver driver) {
		element = driver.findElement(By.xpath("//*[@id=\"a\"]"));
		return element;
	}
	
	public static String getTitle(WebDriver driver) {
		String Title = driver.getTitle();
		return Title;
	}
	

}
