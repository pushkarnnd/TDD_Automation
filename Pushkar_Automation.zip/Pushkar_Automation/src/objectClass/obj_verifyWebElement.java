package objectClass;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Selenium_code.baseTestClass;

public class obj_verifyWebElement extends baseTestClass {

	static WebElement element = null;
	String City_name = "Noida";
	public static void loginMethod(WebDriver driver) throws Exception
	{
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"/test.properties");
		Properties property = new Properties();
		property.load(fs);
		
		driver.findElement(By.name("email")).sendKeys(property.getProperty("EmailID2"));
		driver.findElement(By.name("password")).sendKeys(property.getProperty("Password2"));
		
		driver.findElement(By.id("sTestLoginBtn")).click();
	}
	
	public static WebElement logoCheck(WebDriver driver) {
		element = driver.findElement(By.className("logo"));
		return element;
	}
	
	
}
