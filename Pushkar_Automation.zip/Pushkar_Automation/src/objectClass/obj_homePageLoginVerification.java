package objectClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Selenium_code.baseTestClass;

public class obj_homePageLoginVerification extends baseTestClass {
    
	static WebElement element = null;
	
	public static WebElement userLogInSuccess(WebDriver driver) {
		element = driver.findElement(By.id("sTestLoginBtn"));
		return element;
	}
	
	public static WebElement emailString(WebDriver driver) {;
		element = driver.findElement(By.name("email"));
		return element;
	}
	
	
	public static WebElement passwordString(WebDriver driver) {
		element = driver.findElement(By.name("password"));
		return element;
	}
	
	public static WebElement logoCheck(WebDriver driver) {
		element = driver.findElement(By.className("logo"));
		return element;
	}
	
}
